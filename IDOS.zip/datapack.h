#pragma once
#include <nlohmann/json.hpp>
namespace idos{
    typedef nlohmann::json DataPack;
}